package main

import (
	"bytes"
	"io/ioutil"
	"net/http"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
)

func main() {
	e := echo.New()

	// CORS 미들웨어 설정
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"}, // 모든 출처 허용
		AllowMethods: []string{echo.GET, echo.PUT, echo.POST, echo.DELETE},
		AllowHeaders: []string{echo.HeaderOrigin, echo.HeaderContentType, echo.HeaderAccept},
	}))
	e.Use(middleware.Logger())
	e.Use(middleware.Recover())

	e.POST("/send-slack-message", func(c echo.Context) error {
		// 클라이언트로부터 받은 요청 본문을 읽음
		body, err := ioutil.ReadAll(c.Request().Body)
		if err != nil {
			e.Logger.Error("요청 본문 읽기 실패: ", err)
			return err
		}

		// Slack Webhook URL
		webhookURL := "https://hooks.slack.com/services/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"

		// 받은 데이터를 그대로 Slack Webhook으로 전송
		_, err = http.Post(webhookURL, "application/json", bytes.NewBuffer(body))
		if err != nil {
			e.Logger.Error("Slack 메시지 전송 실패: ", err)
			return err
		}

		return c.NoContent(http.StatusOK)
	})

	e.Logger.Fatal(e.Start(":8080"))
}
