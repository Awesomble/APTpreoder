<script setup lang="ts">
import { ref } from 'vue'
import { useGlobalStore } from '@/store'
import packageJson from '/package.json'
import suniLogo from '@/assets/images/logo-suni.png'
import debugDialog from '@/components/dialogs/Debug.vue'


const golbalStore = useGlobalStore()
const drawer = ref(false)
const DEV_MODE = ref(import.meta.env.DEV)
const STG_MODE = ref(import.meta.env.STG)
const isDebugDialog = ref<boolean>(false)
const open = ref<string[]>(['mypage'])
const menuList = ref<object[]>([
  {
    title: '마이페이지',
    group: 'mypage',
    children: [
      {
        title: '내 요청',
        link: '/approval',
      },
      {
        title: '내 업무',
        link: '/approval',
      },
      {
        title: '신청 현황 및 이력',
        link: '/approval',
      },
    ],
  },
  {
    title: '관리자 메뉴',
    group: 'admin',
    children: [
      {
        title: '사용자 관리',
        link: '/approval',
      },
      {
        title: '로그인 이력',
        link: '/approval',
      },
      {
        title: '관리자 기능 실행 이력',
        link: '/approval',
      },
    ],
  },
  {
    title: 'mySUNI ID',
    group: 'mySUNIID',
    children: [
      {
        title: '어드민 계정',
        link: '/approval',
      },
      {
        title: '인프라 계정',
        link: '/approval',
      },
      {
        title: '자산',
        link: '/approval',
      },
      {
        title: '프로그램/데이터',
        link: '/approval',
      },
      {
        title: '공용문서',
        link: '/approval',
      },
    ],
  },
  {
    title: 'mySUNI',
    group: 'mySUNI',
    children: [],
  },
  {
    title: 'LRS',
    group: 'LRS',
    children: [],
  },
  {
    title: '커리어',
    group: 'career',
    children: [],
  },
  {
    title: '이천포럼',
    group: 'forum',
    children: [],
  },
  {
    title: '서비스 등록',
    group: 'service',
    children: [],
  }
])
function toggleMenu(idx) {
  menuList.value[idx].active = !menuList.value[idx].active
}
</script>

<template>
  <v-navigation-drawer
    color="white"
    permanent
    class='navigation'
    v-model="golbalStore.isNavigation"
  >
    <v-sheet color="info"
              class="pa-5"
    >
      <a href="/"><img :src="suniLogo" alt='suni-logo' height='24' /></a>

      <div class="d-flex align-center justify-space-between mt-6">
        <h1>승인관리 시스템</h1>
        <a href="javascript:;" class='ico-exit' />
      </div>
      <p class="mt-2 text-subtitle-2 font-weight-regular">최근 접속일 : 2023-06-27</p>
      <div class="d-flex align-center justify-space-between">
        <p class="text-subtitle-2 font-weight-regular ">{{ DEV_MODE ? 'DEV' : '' }} {{ STG_MODE ? 'STG' : '' }} v{{ packageJson?.version }}</p>
        <v-btn density="compact" icon="mdi-alert" color='info' @click="isDebugDialog = !isDebugDialog"/>
      </div>
    </v-sheet>
    <v-divider />
    <v-list>

      <v-list-group
        v-for="(item, idx) in menuList"
        :key="`menu${idx}`"
        :value="item.group"
      >
        <template v-slot:activator="{ props }">
          <v-list-item v-bind="props" :title="item.title"></v-list-item>
        </template>

        <v-list-item
          v-for="(child, i) in item.children"
          :key="`menu${idx}${i}`"
          :title="child.title"
          :value="child.title"
        ></v-list-item>
      </v-list-group>
    </v-list>
    <template v-slot:append>
      <p class="text-center">Ⓒ mySUNI.com</p>
    </template>
  </v-navigation-drawer>
  <debugDialog :isShow="isDebugDialog" @close="isDebugDialog = false" />
</template>

<style scoped lang='scss'>
.navigation {
  border-right: 2px solid var(--mysuni-color-gray-07);
}
</style>