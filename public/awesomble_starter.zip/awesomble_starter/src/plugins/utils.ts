// 사용자의 OS 정보를 가져오는 함수
export const getOSInfo = (): string => {
  const userAgent = window.navigator.userAgent;
  const platform = window.navigator.platform;
  let osName = 'unknown';
  let osVersion = 'unknown';

  // MacOS
  if (/Macintosh|MacIntel|MacPPC|Mac68K/.test(platform)) {
    osName = 'Mac OS';
    const macOsVersion = userAgent.match(/Mac OS X (\d+_\d+|\d+)/);
    osVersion = macOsVersion ? macOsVersion[1].replace(/_/g, '.') : 'unknown';
  }
  // iOS
  else if (/iPhone|iPad|iPod/.test(platform)) {
    osName = 'iOS';
    const iosVersion = userAgent.match(/OS (\d+_\d+)/);
    osVersion = iosVersion ? iosVersion[1].replace(/_/g, '.') : 'unknown';
  }
  // Windows
  else if (/Win/.test(platform)) {
    osName = 'Windows';
    osVersion = /Windows NT (\d+\.\d+)/.test(userAgent) ? userAgent.match(/Windows NT (\d+\.\d+)/)[1] : 'unknown';
  }
  // Android
  else if (/Android/.test(userAgent)) {
    osName = 'Android';
    osVersion = /Android (\d+\.\d+)/.test(userAgent) ? userAgent.match(/Android (\d+\.\d+)/)[1] : 'unknown';
  }
  // Linux
  else if (/Linux/.test(platform)) {
    osName = 'Linux';
    // Linux 버전 정보는 일반적으로 사용자 에이전트에 포함되지 않습니다.
  }

  return `${osName} ${osVersion}`;
}

// 브라우저 정보를 가져오는 함수
export const getBrowserInfo = (): string => {
  const userAgent = navigator.userAgent;
  let browserName = 'unknown';
  let browserVersion = 'unknown';

  if (userAgent.match(/chrome|chromium|crios/i)) {
    browserName = 'Chrome';
    browserVersion = userAgent.match(/chrome\/(\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/firefox|fxios/i)) {
    browserName = 'Firefox';
    browserVersion = userAgent.match(/firefox\/(\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/safari/i) && !userAgent.match(/chrome|chromium|crios/i)) {
    browserName = 'Safari';
    browserVersion = userAgent.match(/version\/(\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/opr\//i)) {
    browserName = 'Opera';
    browserVersion = userAgent.match(/opr\/(\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/edg/i)) {
    browserName = 'Edge';
    browserVersion = userAgent.match(/edg\/(\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/msie/i)) {
    browserName = 'Internet Explorer';
    browserVersion = userAgent.match(/msie (\d+\.\d+)/i)?.[1] ?? browserVersion;
  } else if (userAgent.match(/trident/i)) {
    browserName = 'Internet Explorer';
    browserVersion = userAgent.match(/rv:(\d+\.\d+)/i)?.[1] ?? browserVersion;
  }

  return `${browserName} ${browserVersion}`;
}

// 해상도 정보를 가져오는 함수
export const getResolutionInfo = () : string => {
  return `${window.screen.width} x ${window.screen.height}`
}