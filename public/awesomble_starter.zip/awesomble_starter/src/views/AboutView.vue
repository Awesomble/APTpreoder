<script setup lang="ts">
import { useRoute } from 'vue-router'

const route = useRoute()
</script>

<template>
  <div>Home</div>
  {{ route.meta.from }}
  <router-link :to="{name: 'home'}">About</router-link>'
</template>
