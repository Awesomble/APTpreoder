<script setup lang="ts">
import { ref } from 'vue'
</script>

<template>
  <div>Home</div>
</template>
