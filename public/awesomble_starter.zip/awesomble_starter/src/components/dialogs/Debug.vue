<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import packageJson from '/package.json'
import html2canvas from 'html2canvas'
import axios from 'axios'
import { getOSInfo, getBrowserInfo, getResolutionInfo } from '@/plugins/utils'

const route = useRoute()
const emit = defineEmits<{
  (e: string, value: boolean): void
}>()
const DEV_MODE = ref(import.meta.env.DEV)
const STG_MODE = ref(import.meta.env.STG)
const PRD_MODE = ref(import.meta.env.PRD)
const webhookUrl = 'http://localhost:8080/send-slack-message'

const dialog = ref(false)
const props = defineProps({
  isShow: {
    type: Boolean,
    required: false,
  },
})
const iptReport = ref<string>('')
const iptOSBrowser = ref<boolean>(true)
const iptScreenShot = ref<boolean>(true)

const imageUrl = ref<string | null>(null)
const imageBase64 = ref<string | null>(null)

watch(
  () => props.isShow,
  newVal => {
    if (newVal) {
      captureScreen()
      iptReport.value = ''
      iptOSBrowser.value = true
      iptScreenShot.value = true
    }
    dialog.value = props.isShow
  }
)
// sc
const captureScreen = async () => {
  try {
    const canvas = await html2canvas(document.body, {
      scale: 0.4 // 캔버스의 크기를 절반으로 줄임
    });
    const dataUrl = canvas.toDataURL('image/png');
    imageUrl.value = dataUrl;
    imageBase64.value = dataUrl.split(',')[1]; // Base64 인코딩된 부분만 추출
  } catch (error) {
    console.error('화면 캡처 중 오류 발생:', error);
  }
};

const close = () => {
  emit('close', false)
}

const sendCall = async () => {
  try {

    const payload: object[] = []
    if (iptOSBrowser.value) {
      payload.push({
        'type': 'section',
        'text': {
          'type': 'mrkdwn',
          'text': `*OS* \n ${getOSInfo()}`
        }
      })
      payload.push({
        'type': 'section',
        'text': {
          'type': 'mrkdwn',
          'text': `*브라우저* \n ${getBrowserInfo()}`
        }
      })
      payload.push({
        'type': 'section',
        'text': {
          'type': 'mrkdwn',
          'text': `*해상도* \n ${getResolutionInfo()}`
        }
      })
    }

    // 페이지 정보
    payload.push({
      'type': 'section',
      'text': {
        'type': 'mrkdwn',
        'text': `*오류페이지* \n ${route.fullPath}\n *이전페이지* \n ${JSON.stringify(route?.meta?.from)}`
      }
    })
    // 오류내용
    payload.push({
      'type': 'section',
      'text': {
        'type': 'mrkdwn',
        'text': `*오류내용* \n ${iptReport.value}`
      }
    })
    await axios.post(webhookUrl, {'blocks': payload});

    close()
  } catch (error) {
    console.error('Slack 메시지 전송 중 오류 발생:', error)
    alert('메시지 전송에 실패했습니다.');
  }
}

</script>
<template>
  <v-dialog
    v-model="dialog"
    persistent
    color="background"
    width="600"
  >
    <v-card>
      <v-card-title class="pa-5">
        <span class="text-h7 font-weight-bold">오류 전송</span>
        <small> ({{ DEV_MODE ? 'DEV' : '' }}{{ STG_MODE ? 'STG' : '' }}{{ PRD_MODE ? 'PRD' : '' }} v{{ packageJson?.version }}사용중)</small>
      </v-card-title>
      <v-card-text class="pa-5">
        <v-container class="pa-0 mx-0 w-100">
          <v-row class="pa-0 ">
            <v-col
              cols="12"
            >
              <div v-if="imageUrl && iptScreenShot">
                <img :src="imageUrl" alt="캡처된 화면" height='200' width='auto' />
              </div>
              <v-textarea v-model="iptReport" class="mt-2" label="오류내용" variant="outlined" hide-details="auto" />
              <v-checkbox v-model="iptOSBrowser" density="compact" label="OS 및 브라우저 정보를 전송 합니다." hide-details="auto" class="mt-4" />
              <v-checkbox v-model="iptScreenShot" density="compact" label="화면 스크린샷을 전송합니다." hide-details="auto" />
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
      <v-card-actions class="justify-center pa-5 pt-0">
        <v-btn
          class="text-none mb-4"
          color="cancel"
          size="x-large"
          variant="flat"
          @click="close"
        >
          취소
        </v-btn>
        <v-btn
          class="text-none mb-4"
          color="primary"
          size="x-large"
          variant="flat"
          :disabled="!iptReport.trim()"
          @click="sendCall"
        >
          전송
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>

</template>